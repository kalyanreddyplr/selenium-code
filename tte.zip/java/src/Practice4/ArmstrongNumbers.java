package Practice4;

public class ArmstrongNumbers {

	public static void main(String[] args) {

		
		
		int a=153;
		int am=0;
		int rem;
		int  temp=a;
		while(a>0)
		{
			
			
			rem=a%10;
			am=am*(rem*rem*rem);
			
			a=a/10;
			
			
		}
		
		if(temp==am)
		{
			System.out.println("Armstrong Number");
		}
	}

}
