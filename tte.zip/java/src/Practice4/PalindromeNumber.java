package Practice4;

public class PalindromeNumber {

	public static void main(String[] args) {
		
		int a=1;
		int b=1000;
		int count=0;
		for(int i=1;i<=b;i++)
		{
			
			int n=i;
			int rev=0;
			int rem=0;
			int temp=i;
			while(n>0)
			{
				rem=n%10;
				rev=(rev*10)+rem;
				n=n/10;
				
			}
			if(temp==rev)
			{
				count++;
				
				System.out.println("palindrome number is "+i);
			}
			
			
		}
		System.out.println("total count"+count);
	}

}
