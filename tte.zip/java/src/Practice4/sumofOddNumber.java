package Practice4;

public class sumofOddNumber {

	public static void main(String[] args) {
		int count=0;
		
		//1+3+5+7+9=''
		int sum=0;
		for(int i=1;i<=100;i++)
		{
			
			if(i%2==1)
			{
				System.out.println(i);
				sum=sum+i;
				count++;
				
			}
		}
		System.out.println("total sum of odd number="+sum);
		System.out.println("total count odd number="+count);

	}

}
