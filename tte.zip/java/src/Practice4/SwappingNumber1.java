package Practice4;

public class SwappingNumber1 {

	public static void main(String[] args) {
		
		int a=8;
		int b=9;
		System.out.println("Before swapping a="+a+"  b="+b);

		
		a=a+b;//17
		b=a-b; //17-9=8
		a=a-b;//17-8=9
		
		System.out.println("After swapping a="+a+"  b="+b);

	}

}
