package Practice4;

public class FactoralNumber {

	public static void main(String[] args) {

		// 8=8*7*
		int factoral = 1;

		for (int i = 8; i >= 1; i--) {
			factoral = factoral * i;

		}
		System.out.println("factoral=" + factoral);
	}

}
