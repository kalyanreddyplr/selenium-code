package Practice4;

public class SwappingNumber {

	public static void main(String[] args) {

		int a = 10;
		int b = 90;
		System.out.println("Before swapping a=" + a + " b=" + b);

		int c;
c=a;
a=b;
b=c;
		System.out.println("After swapping a=" + a + " b=" + b);

	}

}
