package Practice4;

public class ReverseNumber {

	public static void main(String[] args) {
		
		
		int a=121;
		int rev=0;
				int temp=a;
				
				
				
		int rem=0;
		
		while(a>0)
		{
			
			rem=a%10;
			rev=(rev*10)+rem;
			a=a/10;
			
		}
		
		if(rev==temp)
		{
		System.out.println("Given number is palindrome     "+rev);
	}}

}
