package Practice4;

public class PrimeNumbers {

	public static void main(String[] args) {
int d=0;
//	int b=1;
	//int c=100;
	for(int b=1;b<=100;b++)
	{
		int a=b;
		int count=0;
		for(int i=1;i<=a;i++)
		{
			
			if(a%i==0)
			{
				count++;
				
			}
		}
		if(count==2)
		{
			System.out.println("Given number is Prime = "+b);
			d++;
			
		}
		
		/*
		 * else { System.out.println("Not a prime"); }
		 */
	}
	System.out.println("total no of count = "+d);

}}
