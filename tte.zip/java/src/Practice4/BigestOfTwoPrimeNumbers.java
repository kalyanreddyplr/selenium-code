package Practice4;

public class BigestOfTwoPrimeNumbers {

	public static void main(String[] args) {
		
		int a=90;
		int b=11;
		int c=1;
		int d=123;
		
		if(a>b && a>c && a>d)
		{
			
			System.out.println("a is big number ="+a);
		}
		
		else if(b>c && b>d &&b>a)
		{
			System.out.println("b is big numbner ="+b);
		}
		else if()


	}

}
