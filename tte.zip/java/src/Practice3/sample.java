package Practice3;

public class sample {

	public static void main(String[] args) {

		String a = "  kalyan";

		System.out.println("a");
		System.out.println(a.charAt(2));
		System.out.println(a.indexOf("n"));
		System.out.println(a.substring(3, 6));
		System.out.println(a.trim()); // remove the spaces
		System.out.println("sub string " + a.substring(5)); //
		System.out.println(a.concat("reddy"));
		System.out.println(a.toUpperCase()); // to change the upper case

		String arr[] = a.split("a"); // split the specifg
		System.out.println(arr[0]);
		System.out.println(arr[1]);

		System.out.println(a.replace("n", "Reddy")); // for replace
	}

}
