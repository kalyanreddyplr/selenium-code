package Practice3;

public class StringReverse {

	public static void main(String[] args) {
		
		
		
		
		
		String k= "kalyan";
		String rev="";
		
		for(int i=k.length()-1;i>=0;i--)
		{
			rev=rev+k.charAt(i);
			
		}
		System.out.println(rev);
		
		if(k==rev)
		{
			
			System.out.println("this is palindrome");
		}
		else
			System.out.println("not a palindrome");
	}

}
