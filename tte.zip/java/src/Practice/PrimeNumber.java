package Practice;

public class PrimeNumber {

	public static void main(String[] args) {
		
		int n=31;
		int count=0;
		for(int i=1;i<=n;i++)
		{
			
		if(n%i==0)
		{
			count++;
			System.out.println(i);
		}
		
		}
		if(count==2)
		{
			System.out.println("Given Number is  PrimeNumber");
		}
		else
			System.out.println("Not a prime Numbers ");
	
	}

}
