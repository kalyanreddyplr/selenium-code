package Practice;



public class ReverseNumber {
	public static void main(String[] args) {
		
		/*
		 * Scanner rn = new Scanner(System.in); System.out.println("Enter a number");
		 * int n = rn.nextInt(); int a, i = 0, j = 0; a = n; while (a > 0) { i = a % 10;
		 * j = (j * 10) + i; a = a / 10; } System.out.println("Reverse number is=" + j);
		 */	
		int n=12263;
		int rev=0;
		int rem;
		int temp=n;
		while(n>0)
		{
			rem=n%10; 
			rev=(rev*10)+rem;
			n=n/10;
			
		}
		System.out.println(rev);
		if(rev==temp)
			System.out.println("Given Number is palindrome");
		else 
			System.out.println("Given Number is not palindrome Number");
	}

}
