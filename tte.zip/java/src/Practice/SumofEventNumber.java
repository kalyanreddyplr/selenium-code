package Practice;

public class SumofEventNumber {
	public  static void main(String[]ardd)
	{
		
int a=100;
int sum=0;
for(int i=1;i<=a;i++)
{
	
	if(i%2==1)
	{
	sum=sum++;
	
	}
}

}}
