package Practice;





public class Test1 {

	
	
	int id;
	String name;
	class test2{
		
		public static void main(String[] args) {
			Test1 tt=new Test1();
		System.out.println(tt.id);
		}
	}
}
