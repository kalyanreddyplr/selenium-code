package Practice;

public class RemoveSpece {

	public static void main(String[] args) {
		
		
		
		String name="k alyan  red  dy";
		
		String newname=name.replace(" ", "@");
		System.out.println(newname);
		
	}

}
