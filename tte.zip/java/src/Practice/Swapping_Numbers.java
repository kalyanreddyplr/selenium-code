package Practice;
public class Swapping_Numbers {
	public static void main(String[] args) {
		int a=12;
		int b=6;	
		int c;
		
		System.out.println("Before Swapping A="+a+" B="+b);
		
		c=a;
		a=b;
		b=c;
		System.out.println("After Swapping A="+a+ " B="+b);
		
		
	}

}
