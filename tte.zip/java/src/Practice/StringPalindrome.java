package Practice;

public class StringPalindrome {

	public static void main(String[] args) {

		
		String k="MOM";
		String rev="";
		for(int i=k.length()-1;i>=0;i--) {
			
			rev=rev+k.charAt(i);
			
		}
		
		if(k.equals(rev))
		{
			System.out.println("given number is palindrome");
		}
		else
			System.out.println("Given number is not a palindrome");
		
	}

}
