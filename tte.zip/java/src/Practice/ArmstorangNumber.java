package Practice;

public class ArmstorangNumber {

	public static void main(String[] args) {

		int a = 1;
		int count = 0;
		for (int i = a; i <= 1000; i++) {

			int n = i;
//int n=153;
			int rev = 0;
			int rem;
			int temp = n;
			while (n > 0) {
				rem = n%10;
				rev = rev + (rem *rem * rem);
				n = n/10;
			}
			//System.out.println(rev);
			if (temp == rev)

			{
				System.out.println("given number is ArmstorangNumber = "+rev);
			count=count+1;
  
			}}
System.out.println("total armstorangeNumbers = "+count);
		}
	
}
