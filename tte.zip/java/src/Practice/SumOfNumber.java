package Practice;

public class SumOfNumber {

	public static void main(String[] args) {
		
		int a=236;
		
		int sum=0;
		
		int rem;

		
		while(a>0)
		{
			rem=a%10;
			sum=sum+rem;
			a=a/10;
			
			
		}
		System.out.println(sum);
	}

}
