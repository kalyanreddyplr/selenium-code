package Practice;

public class SplitToSpece {

	public static void main(String[] args) {
	
	String k="This kalyan virat from hyderabad";
	
	String[] rr=k.split("v");
	
	for(int i=0;i<rr.length;i++)
	{
		System.out.println(rr[i]);
	}
	//class Table{  
	}

}
