package Practice;

public class TringlePrograme2 {

	public static void main(String[] args) {
		
		
		
		for(int i=1;i<=5;i++)
		{
			for(int k=1;k<=5-i;k++)
			{
				System.out.print("8");
			}
			for(int j=1;j<=i;j++)
			{
				System.out.print("* ");
			}
			System.out.println(" ");
		}

	}

}
