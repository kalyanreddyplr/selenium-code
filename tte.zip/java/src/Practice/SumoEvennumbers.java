package Practice;

public class SumoEvennumbers {

	public static void main(String[] args) {
		
int a=100;
int sum=0;
int count=0;

for(int i=1;i<=a;i++)
{
	
	if(i%2==0)
	{
	sum=sum+i;
	//System.out.println(i);
	count++;
	}

	}
System.out.println("Total count= "+count);
System.out.println("Sum of odd numbers="+sum);
}
}