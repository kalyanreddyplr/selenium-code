package Practice;

public class CountOfDigites {

	public static void main(String[] args) {

		int a = 6757;

		int i = 0;
		while (a > 0) {
			a = a / 10; // 6757/10=675/10=67/10=6
			i++;

		}
		System.out.println(i);
	}

}
