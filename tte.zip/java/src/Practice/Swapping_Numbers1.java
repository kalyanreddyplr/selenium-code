package Practice;
public class Swapping_Numbers1 {
public static void main(String[] args) {
		int a = 1;
		int b = 12;
		System.out.println("Before Swapping A=" + a + " B=" + b);
		a = a + b; // 13
		b = a - b; // b=13-12=1
		a = a - b;

		System.out.println("After Swapping A=" + a + " B=" + b);
	}

}
