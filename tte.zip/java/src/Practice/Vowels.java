package Practice;

public class Vowels {

	public static void main(String[] args) {

		String name = "AkalyanuOu";
		int vowels = 0;
		int nonvowels = 0;

		for (int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
			if (ch == 'a' || ch == 'A' || ch == 'E' || ch == 'e' || ch == 'i' || ch == 'I' || ch == 'O' || ch == 'o'
					|| ch == 'u' || ch == 'U') {
				vowels++;

			} else {
				nonvowels++;

			}
		}
		System.out.println("vowels is ==" + vowels);
		System.out.println("non-vowels is ==" + nonvowels);
	}

}
