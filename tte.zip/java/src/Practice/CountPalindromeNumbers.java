package Practice;

public class CountPalindromeNumbers {

	public static void main(String[] args) {

		
		int a=1;
		int b=1000;
		
		int count=0;
		for(int i=1;i<=b;i++)
		{
			int n=i;
			int rev=0;
			int rem;
			int temp=n;
			
			while(n>0)
			{
				rem=n%10;
				rev=(rev*10)+rem;
				n=n/10;
				
						
			}
			if(temp==rev)
			{
				count=count+1;
				//System.out.println("This is palindrome number"+rev);
				
			}}
			System.out.println("Total Palindrome  count= "+count);
			
		
	}

}
