package Practice;

public class FactorialNumber {

	public static void main(String[] args) {

		int a=8; //1*2*2*3*4*5*6*7*8=
		int total=1;
		for(int i=1;i<=a;i++)
		{
			total=total*i;
			
		}
		System.out.println(total);
		
	}

}
