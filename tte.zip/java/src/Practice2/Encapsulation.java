package Practice2;

public class Encapsulation {
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	/*public String getname()
	{
		return name;
	}

	
	public void setname(String name)
	{
		this.name=name;
		
		
		
	}
	*/
	
	
	
	
	
	
}
