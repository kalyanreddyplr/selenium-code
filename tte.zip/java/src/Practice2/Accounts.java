package Practice2;

public class Accounts {

	private long ac_no;

	public long getAc_no() {
		return ac_no;
	}

	public void setAc_no(long ac_no) {
		this.ac_no = ac_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public float getAc_blc() {
		return ac_blc;
	}

	public void setAc_blc(float ac_blc) {
		this.ac_blc = ac_blc;
	}

	private String name, emailid;
	private float ac_blc;

}
