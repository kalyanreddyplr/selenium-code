package Practice2;

public class AccountsTest {

	public static void main(String[] args) {
		
		
		Accounts kk=new Accounts();
		kk.setAc_no(1234);
		kk.setAc_blc(998991);
		kk.setEmailid("kalyabnreddy123@gmail.com");
		kk.setName("kalyan reddy");
		
		System.out.println("ac_no= " +kk.getAc_no()+"\nac_name = "+kk.getName()+"\nemail_id ="+kk.getEmailid()+"\nac balance ="+kk.getAc_no());
		

	}

}
