package Practice2;

public class Encaspulation2 {

	public static void main(String[] args) {

		Encapsulation kk=new Encapsulation();
		kk.setName("kalyan");
		System.out.println(kk.getName());
		
		
	}

}
